#!/data/data/dev.apexstudio.ide/files/usr/bin/bash
source /data/data/dev.apexstudio.ide/files/usr/bin/termux-setup-package-manager || exit 1

terminal_width="$(stty size | cut -d" " -f2)"
if [[ "$terminal_width" =~ ^[0-9]+$ ]] && [ "$terminal_width" -gt 60 ]; then
    motd="
 \e[47m                \e[0m  \e[1mWelcome to Apex Studio!\e[0m
 \e[47m  \e[0m            \e[0;37m\e[47m .\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mDocs:\e[0m      \e[4mhttps://apex-studio-dev.github.io\e[0m
 \e[47m  \e[0m  \e[47m  \e[0m        \e[47m  \e[0m  \e[1mCommunity:\e[0m \e[4mhttps://apex-studio-dev.github.io\e[0m
 \e[47m  \e[0m            \e[47m  \e[0m  \e[1mVersion:\e[0m    ${TERMUX_VERSION:-Unknown}
"
    motd_indent="                   "
else
    motd="
\e[1mWelcome to Apex Studio!\e[0m
\e[2mAndroid Development Environment\e[0m

\e[1mDocs:\e[0m      \e[4mhttps://apex-studio-dev.github.io\e[0m
\e[1mCommunity:\e[0m \e[4mhttps://apex-studio-dev.github.io\e[0m
"
    motd_indent=""
fi

motd+="
${motd_indent}\e[1mWorking with packages:\e[0m
${motd_indent}  \e[1mSearch:\e[0m  pkg search <query>
${motd_indent}  \e[1mInstall:\e[0m pkg install <package>
${motd_indent}  \e[1mUpgrade:\e[0m pkg upgrade
"

echo -e "$motd"
