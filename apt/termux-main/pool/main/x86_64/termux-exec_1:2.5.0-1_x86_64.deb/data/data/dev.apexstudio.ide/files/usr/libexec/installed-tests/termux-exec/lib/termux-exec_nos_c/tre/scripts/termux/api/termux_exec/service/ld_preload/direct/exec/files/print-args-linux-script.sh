#!/data/data/dev.apexstudio.ide/files/usr/bin/sh

echo "$@"
