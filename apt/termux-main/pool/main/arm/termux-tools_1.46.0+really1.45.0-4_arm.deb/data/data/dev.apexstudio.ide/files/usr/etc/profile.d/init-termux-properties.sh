if [ ! -f /data/data/dev.apexstudio.ide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/dev.apexstudio.ide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/dev.apexstudio.ide/files/home/.termux
	cp /data/data/dev.apexstudio.ide/files/usr/share/examples/termux/termux.properties /data/data/dev.apexstudio.ide/files/home/.termux/
fi
