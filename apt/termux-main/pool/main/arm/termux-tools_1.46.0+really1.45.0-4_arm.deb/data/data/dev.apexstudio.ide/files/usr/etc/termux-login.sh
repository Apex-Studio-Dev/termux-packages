##
## This script is sourced by /data/data/dev.apexstudio.ide/files/usr/bin/login before executing shell.
##
